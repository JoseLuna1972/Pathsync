# PathSync

PathSync is a next-generation dispatch and affiliate management platform for the limousine and transportation industry.

## Features
- Real-time ride dispatching
- Automated payments & invoicing
- Affiliate network support
- AI-powered fleet optimization

## Repository Structure
```
📦 PathSync
 ┣ 📂 backend        # Backend services (API, payments, dispatch)
 ┣ 📂 frontend       # Frontend UI (React/Vue)
 ┣ 📂 mobile         # Mobile app (React Native/Flutter)
 ┣ 📂 infra          # Infrastructure & DevOps
 ┣ 📂 docs           # Documentation & API guides
 ┣ 📜 README.md      # Project overview
 ┣ 📜 docker-compose.yml  # Dockerized environment
```

## Getting Started

### 🚀 Backend
```sh
cd backend
pip install -r requirements.txt
python src/app.py
```

### 🚀 Frontend
```sh
cd frontend
npm install
npm start
```

### 🚀 Mobile
```sh
cd mobile
npm install
npm start
```

### 🚀 Running with Docker
```sh
docker-compose up --build
```

## Contribution Guidelines
- Fork the repo and create a new branch
- Submit a PR with clear commit messages
