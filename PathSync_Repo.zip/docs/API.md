# API Documentation

## Authentication

## Ride Dispatch

## Payments