# PathSync Roadmap

## Phase 1
- Dispatch System
- Payments
- Notifications